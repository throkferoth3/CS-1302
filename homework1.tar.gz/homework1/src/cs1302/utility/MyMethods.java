package cs1302.utility;

public class MyMethods {

    public static int max(int x, int y) {
	
	return Math.max(x,y);
	
    }
    
}
